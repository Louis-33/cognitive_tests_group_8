# ANS Test Code Group 8

This is the Approximate Number Sense Test.

Click "Run All" to start the test. 
There are 47 questions in this test. 
Choose which one has more circles by typing 'y' for yellow or 'b' for blue.

There have been certain changes from the draft. The number of questions were decreased from 53 to 45. The way to answer has changed from typing the whole word to only typing the first letter 'y' or 'b'. The questions in the introduction asking for name, age and gender has been changed so that if invalid characters were inserted, the answer will be rejected.

